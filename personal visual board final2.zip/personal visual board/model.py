
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from database import Base


class CommunicationBoard(Base):
    __tablename__ = "boards"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    content = Column(String)
    custom_symbols = Column(String)
    accessibility_options = Column(String)
    layout = Column(String)

    # Add a foreign key to link each board to its creator
    user_id = Column(Integer, ForeignKey("SignUp.id"))
    creator = relationship("SignUp", back_populates="boards")


class SignUp(Base):
    __tablename__ = "SignUp"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password_hash = Column(String)
    email = Column(String, unique=True, index=True)

    # Add a relationship to boards
    boards = relationship("CommunicationBoard", back_populates="creator")
