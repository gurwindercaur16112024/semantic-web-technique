
#main.py
from fastapi import (
    FastAPI,
    Request,
    Form,
    Depends,
    HTTPException,
    status,
    Response,
    Cookie,
)
from funcion import calculate_word_behavior
import json
from datetime import datetime, timedelta
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from model import Base, CommunicationBoard, SignUp
from rdflib import Graph, Literal, URIRef
from rdflib.namespace import RDF, RDFS
import jwt
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from funcion import calculate_word_frequency,calculate_letter_frequency

app = FastAPI()
templates = Jinja2Templates(directory="templates")
Base.metadata.create_all(bind=engine)

SECRET_KEY = "jfdskfdsjfbsdf"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: timedelta):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def authenticate_user(db: Session, username: str, password: str):
    user = db.query(SignUp).filter(SignUp.username == username).first()
    if not user or not verify_password(password, user.password_hash):
        return False
    return user


def get_current_user(request: Request):
    return request.cookies.get("user")


def set_current_user(response: Response, user: str):
    response.set_cookie(key="user", value=user, httponly=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Add Semantic Web integration using rdflib for querying RDF data with SPARQL
def query_rdf_data(graph: Graph, sparql_query: str) -> Graph:
    result_graph = Graph()
    result_graph += graph.query(sparql_query)
    return result_graph


# Add privacy and security enhancements (encryption, access control)
def encrypt_data(data: str) -> str:
    # Implement encryption logic here
    return data


def decrypt_data(encrypted_data: str) -> str:
    # Implement decryption logic here
    return encrypted_data


@app.get("/create_board", response_class=HTMLResponse)
async def index(request: Request, db: Session = Depends(get_db)):
    # Retrieve communication boards from the database
    boards = db.query(CommunicationBoard).all()

    # Convert communication boards to RDF triples
    g = Graph()
    for board in boards:
        board_uri = URIRef(f"urn:board:{board.id}")
        g.add(
            (
                board_uri,
                RDF.type,
                URIRef(
                    "http://PersonalizedVisualBoards.org/ontology/CommunicationBoard"
                ),
            )
        )
        g.add((board_uri, RDFS.label, Literal(board.name)))
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/content"),
                Literal(board.content),
            )
        )
        # Add custom symbols, layout, and accessibility options to RDF graph
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/customSymbols"),
                Literal(board.custom_symbols),
            )
        )
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/layout"),
                Literal(board.layout),
            )
        )
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/accessibilityOptions"),
                Literal(board.accessibility_options),
            )
        )

    # Render RDF graph as Turtle format
    rdf_data = g.serialize(format="turtle")

    return templates.TemplateResponse(
        "index.html", {"request": request, "rdf_data": rdf_data}
    )


@app.post("/create_board", response_class=HTMLResponse)
async def create_board(
    request: Request,
    name: str = Form(...),
    content: str = Form(...),
    custom_symbols: str = Form(...),
    layout: str = Form(...),
    accessibility_options: str = Form(...),
    db: Session = Depends(get_db),
):
    

    new_board = CommunicationBoard(
        name=name,
        content=content,
        custom_symbols=custom_symbols,
        layout=layout,
        accessibility_options=accessibility_options,
    )
    db.add(new_board)
    db.commit()
    text = " ".join([name, content, custom_symbols, layout, accessibility_options])
        # Analyze word behavior
    word_behavior = calculate_word_behavior(text)

    # Convert word behavior data to JSON for passing to JavaScript
    word_behavior_json = json.dumps(word_behavior)
    # Retrieve communication boards from the database
    boards = db.query(CommunicationBoard).all()

    # Convert communication boards to RDF triples
    g = Graph()
    for board in boards:
        board_uri = URIRef(f"urn:board:{board.id}")
        g.add(
            (
                board_uri,
                RDF.type,
                URIRef(
                    "http://PersonalizedVisualBoards.org/ontology/CommunicationBoard"
                ),
            )
        )
        g.add((board_uri, RDFS.label, Literal(board.name)))
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/content"),
                Literal(board.content),
            )
        )
        # Add custom symbols, layout, and accessibility options to RDF graph
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/customSymbols"),
                Literal(board.custom_symbols),
            )
        )
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/layout"),
                Literal(board.layout),
            )
        )
        g.add(
            (
                board_uri,
                URIRef("http://example.org/ontology/accessibilityOptions"),
                Literal(board.accessibility_options),
            )
        )

    # Render RDF graph as Turtle format
    rdf_data = g.serialize(format="turtle")
    text = f"{name} {content} {custom_symbols} {layout} {accessibility_options}"
    word_freq = calculate_word_frequency(text)
    letter_freq = calculate_letter_frequency(text)
    
    # Convert word frequency data to JSON for passing to JavaScript
    word_freq_json = json.dumps(word_freq)
    letter_freq_json = json.dumps(letter_freq)
    # Render the template with data
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "rdf_data": rdf_data, "word_freq_json": word_freq_json, "letter_freq_json": letter_freq_json, "word_behavior_json": word_behavior_json},
    )
    


@app.get("/", response_class=HTMLResponse)
async def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/login", response_class=RedirectResponse)
async def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends()):
    db = SessionLocal()
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    set_current_user(Response(), user.username)
    return RedirectResponse("/create_board", status_code=303)


@app.get("/signup", response_class=HTMLResponse)
async def signup_form(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})


@app.post("/signup")
async def signup(
    request: Request,
    new_username: str = Form(...),
    new_password: str = Form(...),
    email: str = Form(...),
    db: Session = Depends(get_db),
):
    existing_email = db.query(SignUp).filter(SignUp.email == email).first()
    if existing_email:
        return "Email already exists. Please use a different email."

    hashed_password = get_password_hash(new_password)

    new_user = SignUp(
        username=new_username,
        email=email,
        password_hash=hashed_password,
    )

    db.add(new_user)
    db.commit()

    return RedirectResponse("/create_board", status_code=303)


@app.get("/logout")
async def logout(request: Request):
    response = RedirectResponse("/login")
    response.delete_cookie("user")
    return response
@app.get("/word_frequency", response_class=HTMLResponse)
async def word_frequency(request: Request):
    # Retrieve communication boards from the database
    boards = db.query(CommunicationBoard).all()

    # Convert communication boards to RDF triples
    g = Graph()
    for board in boards:
        # Your RDF conversion logic...

        # Render RDF graph as Turtle format
        rdf_data = g.serialize(format="turtle")

        text = extract_text_from_html(rdf_data)
        word_freq = calculate_word_frequency(text)

        return templates.TemplateResponse(
            "word_frequency.html", {"request": request, "word_freq": word_freq}
        )
