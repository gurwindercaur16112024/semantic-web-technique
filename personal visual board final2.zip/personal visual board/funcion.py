from bs4 import BeautifulSoup

def extract_text_from_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    # Extract text from all <pre> tags
    pre_tags = soup.find_all('pre')
    text = ' '.join(tag.get_text() for tag in pre_tags)
    return text
from collections import Counter
import re

def calculate_word_frequency(text):
    # Remove punctuation and convert text to lowercase
    cleaned_text = re.sub(r'[^\w\s]', '', text.lower())
    # Split text into words and count frequency
    word_freq = Counter(cleaned_text.split())
    return word_freq

def calculate_letter_frequency(text):
    # Remove punctuation and convert text to lowercase
    cleaned_text = re.sub(r'[^\w\s]', '', text.lower())
    # Count letter frequency
    letter_freq = Counter(cleaned_text)
    return letter_freq

def calculate_word_behavior(text: str):
    words = text.split()

    # Calculate word frequency
    word_freq = {}
    for word in words:
        word_freq[word] = word_freq.get(word, 0) + 1

    # Calculate word length
    word_length = {word: len(word) for word in words}

    # Calculate word position
    word_position = {word: i + 1 for i, word in enumerate(words)}

    return {
        "word_freq": word_freq,
        "word_length": word_length,
        "word_position": word_position,
    }